/**
 * ตัวสร้างข้อมูลตัวอย่าง — แหล่งข้อมูลหลักของระบบตอนนี้
 *
 * เดิมระบบนี้เคยดึงข้อมูลจาก Leetify Public API แต่ถอดออกแล้วเพราะ
 * (1) ToS ของ Leetify ห้ามเก็บข้อมูลจาก API ไว้ ทำให้ทำ cache ไม่ได้เลย
 *     ต้องยิง API สดทุกครั้ง เสี่ยง rate limit ตลอดเวลา
 * (2) ทำให้โปรเจกต์กลายเป็นแค่ "เว็บห่อ API คนอื่น" ซึ่งไม่ตรงกับ proposal เดิม
 *     ที่วางไว้ว่าจะ parse ไฟล์ .dem และวิเคราะห์เอง
 *
 * ข้อมูลจากไฟล์นี้คือ placeholder ชั่วคราว โครงสร้างตรงกับ 5 มิติ KPI ที่
 * ออกแบบเองใน lib/kpi.js (aim, positioning, utility, clutch, opening)
 * เมื่อ pipeline parse ไฟล์ .dem ด้วย awpy เสร็จ (ดู README หัวข้อ Roadmap)
 * ให้เขียนฟังก์ชันที่หน้าตา/return type เหมือนไฟล์นี้ทุกตัว แล้วสลับ import
 * ใน routes/players.js และ routes/matches.js — ไม่ต้องแก้ route หรือ frontend เลย
 */
const MAPS = ['de_mirage', 'de_inferno', 'de_nuke', 'de_ancient', 'de_dust2', 'de_anubis'];

function seeded(steam64Id) {
  let h = 0;
  for (const ch of String(steam64Id)) h = (h * 31 + ch.charCodeAt(0)) % 100000;
  let s = h || 12345;
  return () => {
    s = (s * 1103515245 + 12345) % 2147483648;
    return s / 2147483648;
  };
}

export function generateProfile(steam64Id) {
  const r = seeded(steam64Id);
  const pick = (min, max) => +(min + r() * (max - min)).toFixed(2);
  return {
    winrate: pick(0.38, 0.62),
    total_matches: Math.floor(80 + r() * 400),
    first_match_date: '2023-04-11T00:00:00.000Z',
    name: `Player_${String(steam64Id).slice(-4)}`,
    steam64_id: String(steam64Id),
    premier_rank: Math.floor(8000 + r() * 14000),
    rating: {
      aim: pick(-8, 12),
      positioning: pick(-8, 10),
      utility: pick(-6, 8),
      clutch: pick(-10, 12),
      opening: pick(-9, 9),
    },
    stats: {
      accuracy_head: pick(18, 34),
      preaim: pick(4.5, 14),
      reaction_time_ms: Math.floor(380 + r() * 260),
      spray_accuracy: pick(15, 32),
      t_opening_duel_success_percentage: pick(0.32, 0.6),
      ct_opening_duel_success_percentage: pick(0.35, 0.62),
      utility_on_death_avg: pick(100, 420),
    },
    recent_matches: generateMatches(steam64Id).slice(0, 10),
  };
}

export function generateMatches(steam64Id) {
  const r = seeded(steam64Id + 'm');
  const out = [];
  for (let i = 0; i < 20; i++) {
    const a = Math.floor(r() * 14);
    const b = a >= 13 ? Math.floor(r() * 13) : 13;
    out.push({
      id: `sample-${steam64Id}-${i}`,
      finished_at: new Date(Date.now() - i * 86400000 * 1.4).toISOString(),
      outcome: a > b ? 'win' : a === b ? 'tie' : 'loss',
      map_name: MAPS[Math.floor(r() * MAPS.length)],
      performance_rating: +((r() - 0.45) * 12).toFixed(2),
      score: [a, b],
      preaim: +(5 + r() * 8).toFixed(2),
    });
  }
  return out;
}

export function generateMatchDetails(gameId) {
  const r = seeded(gameId);
  const stats = [];
  for (let i = 0; i < 10; i++) {
    const kills = Math.floor(5 + r() * 22);
    const deaths = Math.floor(8 + r() * 16);
    stats.push({
      steam64_id: `7656119800000${String(1000 + i)}`,
      name: `Player${i + 1}`,
      initial_team_number: i < 5 ? 2 : 3,
      total_kills: kills,
      total_deaths: deaths,
      total_assists: Math.floor(r() * 8),
      kd_ratio: +(kills / Math.max(deaths, 1)).toFixed(2),
      dpr: +(60 + r() * 50).toFixed(1),
      performance_rating: +((r() - 0.45) * 12).toFixed(2),
      total_hs_kills: Math.floor(kills * (0.3 + r() * 0.4)),
    });
  }
  return {
    id: String(gameId),
    finished_at: new Date(Date.now() - 86400000).toISOString(),
    map_name: MAPS[Math.floor(r() * MAPS.length)],
    team_scores: [
      { team_number: 2, score: 13 },
      { team_number: 3, score: 11 },
    ],
    stats,
  };
}
