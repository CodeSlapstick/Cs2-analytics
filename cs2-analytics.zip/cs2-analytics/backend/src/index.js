import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import { config } from './config.js';
import { attachUser } from './lib/auth.js';
import { authRouter } from './routes/auth.js';
import { playersRouter } from './routes/players.js';
import { matchesRouter } from './routes/matches.js';
import { teamsRouter } from './routes/teams.js';

const app = express();

app.use(cors({ origin: config.frontendUrl, credentials: true }));
app.use(express.json({ limit: '256kb' }));
app.use(cookieParser());
app.use(attachUser);

app.get('/health', (_req, res) => res.json({ ok: true, steam_key: Boolean(config.steamApiKey) }));

app.use('/auth', authRouter);
app.use('/api', playersRouter);
app.use('/api', matchesRouter);
app.use('/api', teamsRouter);

app.use((_req, res) => res.status(404).json({ error: 'ไม่พบเส้นทางนี้' }));

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  console.error('[error]', err);
  const status = err.status || 500;
  res.status(status).json({
    error: status === 500 ? 'เกิดข้อผิดพลาดภายในระบบ' : err.message,
  });
});

app.listen(config.port, () => {
  console.log(`API พร้อมใช้งานที่ ${config.backendUrl}`);
});
