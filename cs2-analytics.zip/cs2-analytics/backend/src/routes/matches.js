import { Router } from 'express';
import { db } from '../db.js';
import { requireAuth } from '../lib/auth.js';
import { generateMatchDetails } from '../services/sampleData.js';

export const matchesRouter = Router();

matchesRouter.get('/matches/:gameId', requireAuth, (req, res) => {
  const match = generateMatchDetails(req.params.gameId);
  const notes = db
    .prepare(
      `SELECT n.id, n.body, n.created_at, u.display_name AS author
       FROM coach_notes n JOIN users u ON u.id = n.author_id
       WHERE n.match_id = ? ORDER BY n.created_at DESC`
    )
    .all(req.params.gameId);
  res.json({ match, notes });
});

matchesRouter.post('/matches/:gameId/notes', requireAuth, (req, res) => {
  const body = String(req.body?.body || '').trim();
  if (!body) return res.status(400).json({ error: 'โน้ตว่างไม่ได้' });
  if (body.length > 4000) return res.status(400).json({ error: 'โน้ตยาวเกิน 4000 ตัวอักษร' });

  const teamId = req.body?.team_id ? Number(req.body.team_id) : null;
  const info = db
    .prepare('INSERT INTO coach_notes (author_id, match_id, team_id, body) VALUES (?, ?, ?, ?)')
    .run(req.user.sub, req.params.gameId, teamId, body);

  const note = db
    .prepare(
      `SELECT n.id, n.body, n.created_at, u.display_name AS author
       FROM coach_notes n JOIN users u ON u.id = n.author_id WHERE n.id = ?`
    )
    .get(info.lastInsertRowid);
  res.status(201).json(note);
});

matchesRouter.delete('/notes/:id', requireAuth, (req, res) => {
  const info = db
    .prepare('DELETE FROM coach_notes WHERE id = ? AND author_id = ?')
    .run(Number(req.params.id), req.user.sub);
  if (info.changes === 0) return res.status(404).json({ error: 'ไม่พบโน้ต หรือไม่ใช่โน้ตของคุณ' });
  res.json({ ok: true });
});
