import { Router } from 'express';
import { db } from '../db.js';
import { requireAuth } from '../lib/auth.js';
import { generateProfile, generateMatches } from '../services/sampleData.js';
import { KPI_DIMENSIONS } from '../lib/kpi.js';

export const playersRouter = Router();

const isSteam64 = (v) => /^\d{17}$/.test(String(v || ''));

playersRouter.get('/me', requireAuth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.sub);
  res.json({ user });
});

playersRouter.get('/players/:steam64', requireAuth, (req, res) => {
  if (!isSteam64(req.params.steam64)) {
    return res.status(400).json({ error: 'steam64_id ต้องเป็นตัวเลข 17 หลัก' });
  }
  res.json(generateProfile(req.params.steam64));
});

playersRouter.get('/players/:steam64/matches', requireAuth, (req, res) => {
  if (!isSteam64(req.params.steam64)) {
    return res.status(400).json({ error: 'steam64_id ต้องเป็นตัวเลข 17 หลัก' });
  }
  res.json(generateMatches(req.params.steam64));
});

// เปรียบเทียบผู้เล่นสองคนแบบตัวต่อตัว (ผู้เล่นเรา vs ผู้เล่นคู่แข่ง)
playersRouter.get('/compare', requireAuth, (req, res) => {
  const { a, b } = req.query;
  if (!isSteam64(a) || !isSteam64(b)) {
    return res.status(400).json({ error: 'ต้องส่ง a และ b เป็น steam64_id 17 หลัก' });
  }
  const pa = generateProfile(a);
  const pb = generateProfile(b);
  const diff = {};
  for (const d of KPI_DIMENSIONS) {
    const va = Number(pa?.rating?.[d]);
    const vb = Number(pb?.rating?.[d]);
    diff[d] = Number.isFinite(va) && Number.isFinite(vb) ? +(va - vb).toFixed(2) : null;
  }
  res.json({ a: pa, b: pb, diff });
});
