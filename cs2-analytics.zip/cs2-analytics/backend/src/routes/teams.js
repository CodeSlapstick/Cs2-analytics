import { Router } from 'express';
import { db } from '../db.js';
import { requireAuth } from '../lib/auth.js';
import { generateProfile } from '../services/sampleData.js';
import { normalizeWeights, scorePlayer, teamProfile, KPI_DIMENSIONS } from '../lib/kpi.js';

export const teamsRouter = Router();

const isSteam64 = (v) => /^\d{17}$/.test(String(v || ''));

function ownedTeam(teamId, userId) {
  return db.prepare('SELECT * FROM teams WHERE id = ? AND owner_id = ?').get(Number(teamId), userId);
}

teamsRouter.get('/teams', requireAuth, (req, res) => {
  const teams = db
    .prepare(
      `SELECT t.*, (SELECT COUNT(*) FROM team_members m WHERE m.team_id = t.id) AS member_count
       FROM teams t WHERE t.owner_id = ? ORDER BY t.is_opponent, t.created_at`
    )
    .all(req.user.sub);
  res.json(teams.map((t) => ({ ...t, kpi_weights: JSON.parse(t.kpi_weights) })));
});

teamsRouter.post('/teams', requireAuth, (req, res) => {
  const name = String(req.body?.name || '').trim();
  if (!name) return res.status(400).json({ error: 'ต้องตั้งชื่อทีม' });
  const isOpponent = req.body?.is_opponent ? 1 : 0;
  const info = db
    .prepare('INSERT INTO teams (name, owner_id, is_opponent) VALUES (?, ?, ?)')
    .run(name.slice(0, 80), req.user.sub, isOpponent);
  const team = db.prepare('SELECT * FROM teams WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json({ ...team, kpi_weights: JSON.parse(team.kpi_weights) });
});

teamsRouter.delete('/teams/:id', requireAuth, (req, res) => {
  const info = db
    .prepare('DELETE FROM teams WHERE id = ? AND owner_id = ?')
    .run(Number(req.params.id), req.user.sub);
  if (info.changes === 0) return res.status(404).json({ error: 'ไม่พบทีม' });
  res.json({ ok: true });
});

teamsRouter.put('/teams/:id/kpi-weights', requireAuth, (req, res) => {
  const team = ownedTeam(req.params.id, req.user.sub);
  if (!team) return res.status(404).json({ error: 'ไม่พบทีม' });
  const weights = normalizeWeights(req.body?.weights);
  db.prepare('UPDATE teams SET kpi_weights = ? WHERE id = ?').run(JSON.stringify(weights), team.id);
  res.json({ ok: true, weights });
});

teamsRouter.post('/teams/:id/members', requireAuth, (req, res) => {
  const team = ownedTeam(req.params.id, req.user.sub);
  if (!team) return res.status(404).json({ error: 'ไม่พบทีม' });

  const steam64Id = String(req.body?.steam64_id || '').trim();
  if (!isSteam64(steam64Id)) {
    return res.status(400).json({ error: 'steam64_id ต้องเป็นตัวเลข 17 หลัก' });
  }
  const count = db.prepare('SELECT COUNT(*) c FROM team_members WHERE team_id = ?').get(team.id).c;
  if (count >= 10) return res.status(400).json({ error: 'หนึ่งทีมเพิ่มได้ไม่เกิน 10 คน' });

  try {
    db.prepare('INSERT INTO team_members (team_id, steam64_id, nickname, role) VALUES (?, ?, ?, ?)').run(
      team.id,
      steam64Id,
      String(req.body?.nickname || '').slice(0, 40) || null,
      String(req.body?.role || '').slice(0, 30) || null
    );
  } catch (e) {
    if (String(e.message).includes('UNIQUE')) {
      return res.status(409).json({ error: 'ผู้เล่นคนนี้อยู่ในทีมแล้ว' });
    }
    throw e;
  }
  res.status(201).json({ ok: true });
});

teamsRouter.delete('/teams/:id/members/:memberId', requireAuth, (req, res) => {
  const team = ownedTeam(req.params.id, req.user.sub);
  if (!team) return res.status(404).json({ error: 'ไม่พบทีม' });
  db.prepare('DELETE FROM team_members WHERE id = ? AND team_id = ?').run(
    Number(req.params.memberId),
    team.id
  );
  res.json({ ok: true });
});

/**
 * ภาพรวมทีม — รวมโปรไฟล์ของสมาชิกทุกคนเป็นคะแนนระดับทีมตามน้ำหนัก KPI ที่โค้ชตั้งไว้
 */
teamsRouter.get('/teams/:id/overview', requireAuth, (req, res) => {
  const team = ownedTeam(req.params.id, req.user.sub);
  if (!team) return res.status(404).json({ error: 'ไม่พบทีม' });

  const weights = normalizeWeights(JSON.parse(team.kpi_weights));
  const rows = db.prepare('SELECT * FROM team_members WHERE team_id = ? ORDER BY id').all(team.id);

  const members = rows.map((m) => {
    const p = generateProfile(m.steam64_id);
    return {
      member_id: m.id,
      steam64_id: m.steam64_id,
      nickname: m.nickname || p.name || m.steam64_id,
      role: m.role,
      name: p.name,
      rating: p.rating,
      winrate: p.winrate,
      total_matches: p.total_matches,
      kpi_score: scorePlayer(p.rating, weights),
      error: null,
    };
  });

  const { average, strongest, weakest } = teamProfile(members);
  const scores = members.map((m) => m.kpi_score).filter((v) => v !== null);
    res.json({
      team: { ...team, kpi_weights: weights },
      members,
      summary: {
        dimensions: KPI_DIMENSIONS,
        average_rating: average,
        strongest,
        weakest,
        team_kpi_score: scores.length
          ? +(scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(2)
          : null,
        covered: scores.length,
        total: members.length,
      },
    });
});
