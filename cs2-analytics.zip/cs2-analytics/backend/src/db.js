import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

/**
 * ใช้ node:sqlite ที่ติดมากับ Node.js เอง (เสถียรตั้งแต่ Node 22.13 ขึ้นไป)
 *
 * ⚠️ อย่าเปลี่ยนกลับไปใช้ better-sqlite3 — มันเคยถูกเปลี่ยนกลับมาแล้วครั้งหนึ่งตอนแก้ปัญหา
 * ติดตั้งบน Windows (native module ต้อง compile ด้วย Visual Studio Build Tools ซึ่งส่วนใหญ่ไม่มี)
 * ถ้าเจอปัญหาติดตั้งอีก ให้แก้ที่ node:sqlite ไม่ใช่เปลี่ยน driver กลับ
 *
 * ⚠️ ห้ามเพิ่มตารางสำหรับ "เก็บผลลัพธ์จาก API ภายนอก" กลับเข้ามา
 * เคยมีตาราง api_cache เก็บผลจาก Leetify API ซึ่งขัดกับ ToS ของเขา — ตอนนี้เอา
 * Leetify ออกจากระบบไปแล้วทั้งหมด (ดู services/sampleData.js) แต่หลักการเดิม
 * ยังใช้ได้เผื่ออนาคตเชื่อม API ภายนอกตัวอื่น: เช็ค ToS ก่อนเสมอว่าเก็บข้อมูลได้ไหม
 */
const file = resolve(process.cwd(), 'data/app.db');
mkdirSync(dirname(file), { recursive: true });

export const db = new DatabaseSync(file);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  steam64_id    TEXT NOT NULL UNIQUE,
  display_name  TEXT NOT NULL,
  avatar_url    TEXT,
  profile_url   TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  last_login_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS teams (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  name         TEXT NOT NULL,
  owner_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  is_opponent  INTEGER NOT NULL DEFAULT 0,
  kpi_weights  TEXT NOT NULL DEFAULT '{"aim":1,"positioning":1,"utility":1,"clutch":1,"opening":1}',
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS team_members (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  team_id    INTEGER NOT NULL REFERENCES teams(id) ON DELETE CASCADE,
  steam64_id TEXT NOT NULL,
  nickname   TEXT,
  role       TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (team_id, steam64_id)
);

CREATE TABLE IF NOT EXISTS coach_notes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  author_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  match_id   TEXT NOT NULL,
  team_id    INTEGER REFERENCES teams(id) ON DELETE SET NULL,
  body       TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_notes_match ON coach_notes(match_id);
`);

// หมายเหตุ: ตั้งใจไม่มีตาราง api_cache หรือฟังก์ชัน cacheGet/cacheSet ในไฟล์นี้
// ไม่มีการเก็บข้อมูลจาก API ภายนอกไว้ที่ไหนเลยในระบบนี้ — ดู services/sampleData.js
