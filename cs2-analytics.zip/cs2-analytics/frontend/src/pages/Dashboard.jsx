import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../auth-context.js';
import PlayerView from '../components/PlayerView.jsx';
import { Loading, ErrorBox } from '../components/ui.jsx';

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    let alive = true;
    setError(null);
    Promise.all([api.profile(user.steam64_id), api.playerMatches(user.steam64_id)])
      .then(([profile, matches]) => alive && setData({ profile, matches }))
      .catch((e) => alive && setError(e));
    return () => { alive = false; };
  }, [user.steam64_id]);

  if (error) {
    return (
      <>
        <h1>แดชบอร์ดของฉัน</h1>
        <ErrorBox error={error} />
      </>
    );
  }
  if (!data) return <Loading />;

  return <PlayerView profile={data.profile} matches={data.matches} title="แดชบอร์ดของฉัน" />;
}
