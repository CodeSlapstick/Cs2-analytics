import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api.js';
import { Loading, ErrorBox, Signed } from '../components/ui.jsx';

const TEAM_LABEL = { 2: 'ทีม T (เริ่มต้น)', 3: 'ทีม CT (เริ่มต้น)' };

/** SQLite คืนค่าเป็น "YYYY-MM-DD HH:MM:SS" (UTC) — แปลงให้เบราว์เซอร์ทุกตัวอ่านได้ */
const parseSqliteDate = (s) => new Date(String(s).replace(' ', 'T') + 'Z');

function Scoreboard({ stats, teamNumber }) {
  const rows = stats
    .filter((p) => p.initial_team_number === teamNumber)
    .sort((a, b) => (b.performance_rating ?? 0) - (a.performance_rating ?? 0));
  if (rows.length === 0) return null;
  return (
    <div className="card">
      <h3>{TEAM_LABEL[teamNumber] || `ทีม ${teamNumber}`}</h3>
      <table>
        <thead>
          <tr>
            <th>ผู้เล่น</th>
            <th className="num">K</th><th className="num">D</th><th className="num">A</th>
            <th className="num">K/D</th><th className="num">ADR</th>
            <th className="num">HS%</th><th className="num">Rating</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((p) => (
            <tr key={p.steam64_id}>
              <td><Link to={`/player/${p.steam64_id}`}>{p.name}</Link></td>
              <td className="num">{p.total_kills}</td>
              <td className="num">{p.total_deaths}</td>
              <td className="num">{p.total_assists}</td>
              <td className="num">{p.kd_ratio?.toFixed?.(2)}</td>
              <td className="num">{p.dpr?.toFixed?.(0)}</td>
              <td className="num">
                {p.total_kills ? Math.round((p.total_hs_kills / p.total_kills) * 100) : 0}%
              </td>
              <td className="num"><Signed value={p.performance_rating} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function Match() {
  const { gameId } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);

  const load = () => api.match(gameId).then(setData).catch(setError);
  useEffect(() => { setData(null); setError(null); load(); }, [gameId]);

  const addNote = async () => {
    if (!draft.trim()) return;
    setSaving(true);
    try {
      const note = await api.addNote(gameId, draft.trim());
      setData((d) => ({ ...d, notes: [note, ...d.notes] }));
      setDraft('');
    } catch (e) {
      setError(e);
    } finally {
      setSaving(false);
    }
  };

  const removeNote = async (id) => {
    await api.deleteNote(id).catch(() => {});
    setData((d) => ({ ...d, notes: d.notes.filter((n) => n.id !== id) }));
  };

  if (error && !data) return <><h1>รายละเอียดแมตช์</h1><ErrorBox error={error} /></>;
  if (!data) return <Loading />;

  const { match, notes } = data;
  const teams = [...new Set(match.stats.map((p) => p.initial_team_number))].sort();

  return (
    <>
      <h1>{match.map_name}</h1>
      <p className="sub">
        {new Date(match.finished_at).toLocaleString('th-TH')}
        {' · สกอร์ '}
        <span className="mono">{match.team_scores.map((t) => t.score).join(' – ')}</span>
      </p>

      <div className="grid" style={{ marginBottom: 16 }}>
        {teams.map((t) => <Scoreboard key={t} stats={match.stats} teamNumber={t} />)}
      </div>

      <div className="card">
        <h3>โน้ตของโค้ช</h3>
        <p className="small muted" style={{ marginTop: 0 }}>
          บันทึกสิ่งที่เห็นจากแมตช์นี้ไว้ผูกกับตัวแมตช์
        </p>
        <textarea rows={3} value={draft} onChange={(e) => setDraft(e.target.value)}
                  placeholder="เช่น: retake ไซต์ B ช้าเพราะไม่มีคนคุม mid ต้องซ้อม default ใหม่" />
        <div style={{ marginTop: 10 }}>
          <button className="primary" onClick={addNote} disabled={saving || !draft.trim()}>
            {saving ? 'กำลังบันทึก…' : 'บันทึกโน้ต'}
          </button>
        </div>

        {notes.length > 0 && (
          <table style={{ marginTop: 18 }}>
            <tbody>
              {notes.map((n) => (
                <tr key={n.id}>
                  <td>
                    <div>{n.body}</div>
                    <div className="small muted">{n.author} · {parseSqliteDate(n.created_at).toLocaleString('th-TH')}</div>
                  </td>
                  <td className="num" style={{ width: 90 }}>
                    <button className="ghost" onClick={() => removeNote(n.id)}>ลบ</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
