import { useState } from 'react';
import { api } from '../api.js';
import { RatingRadar, Signed, ErrorBox, DIM_LABEL } from '../components/ui.jsx';

export default function Compare() {
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const run = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      setResult(await api.compare(a.trim(), b.trim()));
    } catch (e) {
      setError(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <h1>เทียบผู้เล่นตัวต่อตัว</h1>
      <p className="sub">
        ใส่ Steam64 ID สองคน เพื่อดูว่าผู้เล่นของเราได้เปรียบหรือเสียเปรียบมิติไหน
        (เช่น AWPer ของเรา เทียบกับ AWPer ของคู่แข่ง)
      </p>

      <div className="card" style={{ marginBottom: 16 }}>
        <div className="row">
          <div>
            <label>ผู้เล่นของเรา (Steam64)</label>
            <input value={a} onChange={(e) => setA(e.target.value)} placeholder="765611980…" />
          </div>
          <div>
            <label>ผู้เล่นคู่แข่ง (Steam64)</label>
            <input value={b} onChange={(e) => setB(e.target.value)} placeholder="765611980…" />
          </div>
          <button className="primary" onClick={run} disabled={loading || !a.trim() || !b.trim()}>
            {loading ? 'กำลังดึงข้อมูล…' : 'เปรียบเทียบ'}
          </button>
        </div>
      </div>

      <ErrorBox error={error} />

      {result && (
        <div className="grid cols-2">
          <div className="card">
            <h3>เรดาร์เปรียบเทียบ</h3>
            <RatingRadar
              series={[
                { name: result.a.name || 'ของเรา', rating: result.a.rating },
                { name: result.b.name || 'คู่แข่ง', rating: result.b.rating },
              ]}
            />
          </div>
          <div className="card">
            <h3>ส่วนต่างรายมิติ</h3>
            <table>
              <thead>
                <tr>
                  <th>มิติ</th>
                  <th className="num">{result.a.name}</th>
                  <th className="num">{result.b.name}</th>
                  <th className="num">ส่วนต่าง</th>
                </tr>
              </thead>
              <tbody>
                {Object.keys(DIM_LABEL).map((d) => (
                  <tr key={d}>
                    <td>{DIM_LABEL[d]}</td>
                    <td className="num"><Signed value={result.a.rating?.[d]} /></td>
                    <td className="num"><Signed value={result.b.rating?.[d]} /></td>
                    <td className="num"><strong><Signed value={result.diff[d]} /></strong></td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="small muted">
              ส่วนต่างเป็นบวก = ผู้เล่นของเราดีกว่าในมิตินั้น
            </p>
          </div>
        </div>
      )}
    </>
  );
}
