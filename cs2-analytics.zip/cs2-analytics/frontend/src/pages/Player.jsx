import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api.js';
import PlayerView from '../components/PlayerView.jsx';
import { Loading, ErrorBox } from '../components/ui.jsx';

export default function Player() {
  const { steam64 } = useParams();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    let alive = true;
    setData(null);
    setError(null);
    Promise.all([api.profile(steam64), api.playerMatches(steam64)])
      .then(([profile, matches]) => alive && setData({ profile, matches }))
      .catch((e) => alive && setError(e));
    return () => { alive = false; };
  }, [steam64]);

  if (error) return <><h1>ส่องผู้เล่น</h1><ErrorBox error={error} /></>;
  if (!data) return <Loading />;
  return <PlayerView profile={data.profile} matches={data.matches} />;
}
