import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
         ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';

export const DIM_LABEL = {
  aim: 'เล็ง (Aim)',
  positioning: 'ตำแหน่ง',
  utility: 'ยูทิลิตี้',
  clutch: 'คลัตช์',
  opening: 'เปิดไฟต์',
};

export function Loading({ text = 'กำลังโหลด…' }) {
  return <div className="spinner">{text}</div>;
}

export function ErrorBox({ error }) {
  if (!error) return null;
  return <div className="notice error">{error.message || String(error)}</div>;
}

export function Signed({ value, digits = 2, suffix = '' }) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) {
    return <span className="muted">—</span>;
  }
  const n = Number(value);
  const cls = n > 0 ? 'pos' : n < 0 ? 'neg' : '';
  return <span className={cls}>{n > 0 ? '+' : ''}{n.toFixed(digits)}{suffix}</span>;
}

export function Stat({ value, label }) {
  return (
    <div className="card">
      <div className="stat">{value ?? '—'}</div>
      <div className="stat-label">{label}</div>
    </div>
  );
}

/** เรดาร์เทียบมิติ rating ของผู้เล่น 1–2 คน (หรือทีม) */
export function RatingRadar({ series }) {
  const dims = Object.keys(DIM_LABEL);
  const data = dims.map((d) => {
    const row = { dimension: DIM_LABEL[d] };
    series.forEach((s) => { row[s.name] = Number(s.rating?.[d] ?? 0); });
    return row;
  });
  const colors = ['#e0a33e', '#5b9bf3'];
  return (
    <ResponsiveContainer width="100%" height={300}>
      <RadarChart data={data} outerRadius="72%">
        <PolarGrid stroke="#1e3459" />
        <PolarAngleAxis dataKey="dimension" tick={{ fill: '#8ea3c4', fontSize: 12 }} />
        <PolarRadiusAxis tick={{ fill: '#546b90', fontSize: 10 }} />
        {series.map((s, i) => (
          <Radar key={s.name} name={s.name} dataKey={s.name}
                 stroke={colors[i % colors.length]} fill={colors[i % colors.length]} fillOpacity={0.28} />
        ))}
        {series.length > 1 && <Legend wrapperStyle={{ fontSize: 12 }} />}
        <Tooltip contentStyle={{ background: '#102647', border: '1px solid #1e3459', borderRadius: 8 }} />
      </RadarChart>
    </ResponsiveContainer>
  );
}

/** กราฟฟอร์มย้อนหลัง: performance rating ต่อแมตช์ (เก่า -> ใหม่) */
export function FormChart({ matches }) {
  const data = [...matches].reverse().map((m, i) => ({
    n: i + 1,
    rating: Number(m.performance_rating ?? 0),
    map: m.map_name,
  }));
  return (
    <ResponsiveContainer width="100%" height={240}>
      <LineChart data={data} margin={{ top: 8, right: 12, bottom: 4, left: -18 }}>
        <CartesianGrid stroke="#1e3459" strokeDasharray="3 3" />
        <XAxis dataKey="n" tick={{ fill: '#546b90', fontSize: 11 }} />
        <YAxis tick={{ fill: '#546b90', fontSize: 11 }} />
        <Tooltip
          contentStyle={{ background: '#102647', border: '1px solid #1e3459', borderRadius: 8 }}
          labelFormatter={(v) => `แมตช์ที่ ${v}`}
          formatter={(v, _k, p) => [v, p?.payload?.map || 'rating']}
        />
        <Line type="monotone" dataKey="rating" stroke="#e0a33e" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function Outcome({ value }) {
  const label = { win: 'ชนะ', loss: 'แพ้', tie: 'เสมอ' }[value] || value;
  return <span className={`tag ${value}`}>{label}</span>;
}
