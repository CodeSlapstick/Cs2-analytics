import { Link } from 'react-router-dom';
import { RatingRadar, FormChart, Signed, Stat, Outcome, DIM_LABEL } from './ui.jsx';

const fmtPct = (v) => (v === null || v === undefined ? '—' : `${(Number(v) * 100).toFixed(1)}%`);
const fmtDate = (s) => (s ? new Date(s).toLocaleDateString('th-TH', { day: '2-digit', month: 'short', year: '2-digit' }) : '—');

/** มุมมองโปรไฟล์ผู้เล่น ใช้ร่วมกันทั้งหน้าแดชบอร์ดของเราและหน้าส่องคู่แข่ง */
export default function PlayerView({ profile, matches, title }) {
  if (!profile) return null;

  const recent = matches?.length ? matches : profile.recent_matches || [];
  const wins = recent.filter((m) => m.outcome === 'win').length;

  return (
    <>
      <h1>{title || profile.name}</h1>
      <p className="sub">
        Steam64 <span className="mono">{profile.steam64_id}</span>
        {' · '}
        <a href={`https://steamcommunity.com/profiles/${profile.steam64_id}`} target="_blank" rel="noreferrer">
          โปรไฟล์ Steam
        </a>
      </p>

      <div className="notice" style={{ marginBottom: 16 }}>
        ข้อมูลนี้เป็นข้อมูลตัวอย่าง (sample data) รอ pipeline วิเคราะห์ไฟล์ .dem จริง
      </div>

      <div className="grid cols-4" style={{ marginBottom: 16 }}>
        <Stat value={fmtPct(profile.winrate)} label="อัตราชนะโดยรวม" />
        <Stat value={profile.total_matches ?? '—'} label="แมตช์ทั้งหมด" />
        <Stat value={profile.premier_rank ?? '—'} label="CS Rating (Premier)" />
        <Stat value={`${wins}/${recent.length}`} label="ชนะในแมตช์ล่าสุด" />
      </div>

      <div className="grid cols-2" style={{ marginBottom: 16 }}>
        <div className="card">
          <h3>มิติความสามารถ</h3>
          <RatingRadar series={[{ name: profile.name || 'ผู้เล่น', rating: profile.rating }]} />
          <table style={{ marginTop: 8 }}>
            <tbody>
              {Object.keys(DIM_LABEL).map((d) => (
                <tr key={d}>
                  <td>{DIM_LABEL[d]}</td>
                  <td className="num"><Signed value={profile.rating?.[d]} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="card">
          <h3>ฟอร์มย้อนหลัง</h3>
          {recent.length > 0
            ? <FormChart matches={recent} />
            : <p className="muted small">ยังไม่มีข้อมูลแมตช์</p>}
          <h3 style={{ marginTop: 18 }}>สถิติกลไกการเล่น</h3>
          <table>
            <tbody>
              <tr><td>Preaim (องศา — ยิ่งต่ำยิ่งดี)</td><td className="num">{profile.stats?.preaim?.toFixed?.(2) ?? '—'}</td></tr>
              <tr><td>เวลาตอบสนอง</td><td className="num">{profile.stats?.reaction_time_ms ?? '—'} ms</td></tr>
              <tr><td>ความแม่นยำเมื่อเห็นศัตรู</td><td className="num">{profile.stats?.accuracy_enemy_spotted?.toFixed?.(1) ?? '—'}%</td></tr>
              <tr><td>อัตรายิงหัว</td><td className="num">{profile.stats?.accuracy_head?.toFixed?.(1) ?? '—'}%</td></tr>
              <tr><td>ชนะดวลเปิดฝั่ง T</td><td className="num">{fmtPct(profile.stats?.t_opening_duel_success_percentage)}</td></tr>
              <tr><td>ชนะดวลเปิดฝั่ง CT</td><td className="num">{fmtPct(profile.stats?.ct_opening_duel_success_percentage)}</td></tr>
              <tr><td>ยูทิลิตี้ค้างมือตอนตาย (เฉลี่ย)</td><td className="num">{Math.round(profile.stats?.utility_on_death_avg ?? 0)}</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <h3>แมตช์ล่าสุด</h3>
        {recent.length === 0 ? (
          <p className="muted small">ยังไม่มีข้อมูลแมตช์</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>วันที่</th><th>แมพ</th><th>ผล</th><th className="num">สกอร์</th>
                <th className="num">Rating</th><th className="num">Preaim</th><th></th>
              </tr>
            </thead>
            <tbody>
              {recent.slice(0, 15).map((m) => (
                <tr key={m.id}>
                  <td className="muted">{fmtDate(m.finished_at)}</td>
                  <td>{m.map_name}</td>
                  <td><Outcome value={m.outcome} /></td>
                  <td className="num mono">{m.score?.[0]}–{m.score?.[1]}</td>
                  <td className="num"><Signed value={m.performance_rating} /></td>
                  <td className="num">{m.preaim?.toFixed?.(1) ?? '—'}</td>
                  <td className="num"><Link to={`/match/${m.id}`}>ดูรายละเอียด</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
