import { useEffect, useState } from 'react';
import { Routes, Route, NavLink, Navigate, useLocation } from 'react-router-dom';
import { api } from './api.js';
import { AuthCtx } from './auth-context.js';
import Login from './pages/Login.jsx';
import Dashboard from './pages/Dashboard.jsx';
import Player from './pages/Player.jsx';
import Match from './pages/Match.jsx';
import Teams from './pages/Teams.jsx';
import Compare from './pages/Compare.jsx';
import { Loading } from './components/ui.jsx';

function Nav({ user, onLogout }) {
  const link = ({ isActive }) => (isActive ? 'active' : undefined);
  return (
    <nav className="nav">
      <div className="brand">CS2 <span>Team Analytics</span></div>
      <NavLink to="/" className={link} end>แดชบอร์ด</NavLink>
      <NavLink to="/teams" className={link}>ทีม</NavLink>
      <NavLink to="/compare" className={link}>เทียบผู้เล่น</NavLink>
      <div className="spacer" />
      <div className="who">
        {user?.avatar_url && <img src={user.avatar_url} alt="" />}
        <span>{user?.display_name}</span>
        <button className="ghost" onClick={onLogout}>ออกจากระบบ</button>
      </div>
    </nav>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  const location = useLocation();

  const refresh = () =>
    api.me()
      .then((d) => setUser(d.user))
      .catch(() => setUser(null))
      .finally(() => setReady(true));

  useEffect(() => { refresh(); }, []);

  const logout = async () => {
    await api.logout().catch(() => {});
    setUser(null);
  };

  if (!ready) return <Loading text="กำลังตรวจสอบสถานะการเข้าสู่ระบบ…" />;

  if (!user) {
    return (
      <AuthCtx.Provider value={{ user, refresh }}>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<Navigate to="/login" replace state={{ from: location }} />} />
        </Routes>
      </AuthCtx.Provider>
    );
  }

  return (
    <AuthCtx.Provider value={{ user, refresh }}>
      <Nav user={user} onLogout={logout} />
      <div className="container">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/player/:steam64" element={<Player />} />
          <Route path="/match/:gameId" element={<Match />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="/compare" element={<Compare />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
      <footer className="footer">
        <span>ข้อมูลผู้เล่นในเวอร์ชันนี้เป็นข้อมูลตัวอย่าง</span>
        <span>·</span>
        <span>SP-404 Senior Project · UTCC STECH</span>
      </footer>
    </AuthCtx.Provider>
  );
}
