async function request(path, options = {}) {
  const res = await fetch(path, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const err = new Error(data?.error || `เกิดข้อผิดพลาด (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

export const api = {
  me: () => request('/api/me'),
  logout: () => request('/auth/logout', { method: 'POST' }),
  devLogin: (steam64_id) =>
    request('/auth/dev-login', { method: 'POST', body: JSON.stringify({ steam64_id }) }),

  profile: (steam64) => request(`/api/players/${steam64}`),
  playerMatches: (steam64) => request(`/api/players/${steam64}/matches`),
  compare: (a, b) => request(`/api/compare?a=${a}&b=${b}`),

  match: (gameId) => request(`/api/matches/${gameId}`),
  addNote: (gameId, body) =>
    request(`/api/matches/${gameId}/notes`, { method: 'POST', body: JSON.stringify({ body }) }),
  deleteNote: (id) => request(`/api/notes/${id}`, { method: 'DELETE' }),

  teams: () => request('/api/teams'),
  createTeam: (name, is_opponent = false) =>
    request('/api/teams', { method: 'POST', body: JSON.stringify({ name, is_opponent }) }),
  deleteTeam: (id) => request(`/api/teams/${id}`, { method: 'DELETE' }),
  teamOverview: (id) => request(`/api/teams/${id}/overview`),
  addMember: (id, payload) =>
    request(`/api/teams/${id}/members`, { method: 'POST', body: JSON.stringify(payload) }),
  removeMember: (id, memberId) =>
    request(`/api/teams/${id}/members/${memberId}`, { method: 'DELETE' }),
  setWeights: (id, weights) =>
    request(`/api/teams/${id}/kpi-weights`, { method: 'PUT', body: JSON.stringify({ weights }) }),
};
