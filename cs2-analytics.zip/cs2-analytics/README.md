# CS2 Team Analytics

เว็บแอปวิเคราะห์สมรรถนะทีม Counter-Strike 2 สำหรับโค้ชและนักวิเคราะห์
(SP-404 Senior Project · UTCC STECH)

ล็อกอินด้วย Steam → ดูภาพรวมสมรรถนะทีมและผู้เล่นรายคน → บันทึกโน้ตของโค้ช
ผูกกับแมตช์ → ตั้งน้ำหนัก KPI เองตามสไตล์การเล่นของทีม

---

## ทำไมถึงเลิกใช้ Leetify

เวอร์ชันแรกของโปรเจกต์นี้ดึงข้อมูลสถิติจาก Leetify Public API แต่ถอดออกแล้ว
ด้วยเหตุผลสามข้อ:

1. **ขัดกับ ToS ของ Leetify** — Leetify Developer Guidelines ระบุตรง ๆ ว่า
   ห้ามเก็บข้อมูลที่ได้จาก API ไว้เลย ต้องดึงสดทุกครั้ง
   (อ้างอิง: `leetify.com/blog/leetify-api-developer-guidelines/`)
   ซึ่งทำให้ทำ cache ไม่ได้และเสี่ยงโดน rate limit ตลอดเวลาที่มีคนใช้พร้อมกัน
2. **ไม่ตรงกับที่เสนอไว้ใน proposal** — proposal เดิมวางแผนว่าจะ parse ไฟล์
   `.dem` เองด้วย `awpy` แล้ววิเคราะห์เอง การพึ่ง API ของคนอื่นทั้งหมดทำให้
   โปรเจกต์กลายเป็นแค่ "เว็บห่อ API" ซึ่งไม่ตรงกับสิ่งที่เสนอไว้
3. **ควบคุมไม่ได้** — ทุกครั้งที่ Leetify เปลี่ยนโครงสร้าง response หรือ
   rate limit เข้ม โค้ดฝั่งเราพังตาม ทำให้แก้บั๊กวนซ้ำ ๆ โดยไม่ใช่ปัญหาของเราเอง

**ตอนนี้ระบบไม่เชื่อมกับ API ภายนอกใด ๆ เลย** (ยกเว้น Steam OpenID สำหรับ
login และ Steam Web API สำหรับดึงชื่อ/รูปโปรไฟล์ ซึ่งเป็นคนละเรื่องกัน — ดูหัวข้อ
ถัดไป) ข้อมูลสถิติผู้เล่นตอนนี้มาจาก **ตัวสร้างข้อมูลตัวอย่าง**
(`backend/src/services/sampleData.js`) เพื่อให้หน้าเว็บใช้งานและสาธิตได้ครบ
ระหว่างที่ทีมพัฒนา pipeline parse ไฟล์ `.dem` ของตัวเอง — ดูแผนใน
"งานถัดไปที่แนะนำ" ด้านล่าง

---

## ทำอะไรได้บ้าง

| หน้า | ทำอะไร |
|---|---|
| แดชบอร์ด | โปรไฟล์ตัวเอง — เรดาร์ 5 มิติ, ฟอร์มย้อนหลัง, สถิติกลไก, แมตช์ล่าสุด |
| ผู้เล่น | เปิดดูโปรไฟล์ของใครก็ได้ด้วย Steam64 (ใช้ส่องคู่แข่งก่อนแข่ง) |
| แมตช์ | สกอร์บอร์ดสองฝั่ง + **โน้ตของโค้ช** ผูกกับแมตช์นั้น |
| ทีม | รวมผู้เล่นเป็นทีม → คะแนนทีม, มิติที่แข็ง/อ่อนที่สุด, **Custom KPI** ตั้งน้ำหนักเอง |
| เทียบผู้เล่น | เอาผู้เล่นเราชนกับผู้เล่นคู่แข่งตัวต่อตัว ดูส่วนต่างรายมิติ |

ข้อมูลผู้เล่น/แมตช์ในเวอร์ชันนี้เป็น **ข้อมูลตัวอย่าง** (สุ่มแต่คงที่ตาม
Steam64 ID เดิม จะได้ตัวเลขเดิมทุกครั้ง) เพื่อให้ทุกหน้าทำงานและสาธิตได้ครบ
ส่วน**ระบบ** (auth, ทีม, KPI, โน้ตโค้ช, ฐานข้อมูล) เป็นของจริงที่ใช้งานได้ทันที

---

## เทคโนโลยี

- **Frontend** React 18 + Vite + React Router + Recharts (CSS เขียนเอง ไม่มี framework)
- **Backend** Node.js 22.13+ + Express + SQLite (`node:sqlite` ในตัว Node เอง — ไม่ต้อง compile native module)
- **Auth** Steam OpenID 2.0 (เขียนเอง ~60 บรรทัด ไม่ใช้ passport) + JWT ใน httpOnly cookie
- **ข้อมูล** ตัวสร้างข้อมูลตัวอย่าง (`sampleData.js`) — รอ pipeline parse `.dem` จริง

---

## ติดตั้งและรัน

ต้องมี **Node.js เวอร์ชัน 22.13 ขึ้นไป** (`node -v` เช็กได้ — ต่ำกว่านี้ฐานข้อมูล
จะใช้ไม่ได้ เพราะเราใช้ `node:sqlite` ที่ติดมากับ Node เอง แทน `better-sqlite3`
เพื่อเลี่ยงปัญหา compile native module บน Windows ที่ต้องลง Visual Studio Build Tools)

### 1) ติดตั้ง dependency

```bash
npm run setup
```

### 2) ตั้งค่า .env ของ backend

```bash
cp backend/.env.example backend/.env
```

เปิด `backend/.env` แล้วเติมค่า

| ตัวแปร | เอามาจากไหน | จำเป็นไหม |
|---|---|---|
| `JWT_SECRET` | สุ่มเอง: `openssl rand -hex 32` | **จำเป็น** |
| `STEAM_API_KEY` | https://steamcommunity.com/dev/apikey (ฟรี) | ไม่จำเป็น — ไม่ใส่ก็ล็อกอินได้ปกติ แค่ชื่อจะขึ้นเป็น `Player XXXX` แทนชื่อจริง |

ไม่มีตัวแปรอื่นให้ตั้งแล้ว (ตัด `LEETIFY_API_KEY`, `USE_MOCK_DATA`,
`CACHE_TTL_SECONDS` ออกหมด เพราะไม่มี API ภายนอกให้เรียกอีกต่อไป)

### 3) รัน (เปิดสองเทอร์มินัล)

```bash
# เทอร์มินัลที่ 1
npm run dev:backend     # http://localhost:4000

# เทอร์มินัลที่ 2
npm run dev:frontend    # http://localhost:5173
```

เปิดเบราว์เซอร์ที่ **http://localhost:5173** หน้า login มีกล่อง "โหมดทดสอบ"
ให้ใส่ Steam64 ID (ตัวเลข 17 หลักอะไรก็ได้) เข้าระบบได้ทันทีโดยไม่ต้องผ่าน Steam จริง

---

## Login ด้วย Steam ทำงานยังไง

Steam ไม่ได้ใช้ OAuth แต่ใช้ **OpenID 2.0** ซึ่งเก่ากว่าและทำงานต่างกัน
ขั้นตอนใน `backend/src/services/steam.js`:

1. ผู้ใช้กดปุ่ม → เด้งไป `steamcommunity.com/openid/login` พร้อม `return_to` ที่ชี้กลับมาที่เรา
2. ผู้ใช้ล็อกอินที่ Steam (รหัสผ่านไม่ผ่านเซิร์ฟเวอร์เราเลย)
3. Steam เด้งกลับมาที่ `/auth/steam/return` พร้อมพารามิเตอร์ `openid.*`
4. **เราส่งพารามิเตอร์ทั้งชุดกลับไปถาม Steam ว่าของจริงไหม** (`mode=check_authentication`)
   ขั้นนี้ห้ามข้าม ถ้าเชื่อ `claimed_id` ตรง ๆ ใครก็ปลอมเป็นคนอื่นได้
5. ได้ Steam64 ID → บันทึกผู้ใช้ → ออก JWT ใส่ httpOnly cookie → เด้งกลับ frontend

> **ตอน deploy จริง** ต้องแก้ `BACKEND_URL` ใน `.env` ให้เป็นโดเมนจริง
> เพราะ Steam จะเด้งกลับตาม `return_to` ที่เราส่งไป ถ้ายังเป็น localhost จะกลับมาไม่ได้

Steam Web API (`STEAM_API_KEY`) เป็นคนละเรื่องกับ OpenID — ใช้แค่ดึงชื่อ/รูป
โปรไฟล์มาโชว์หลัง login สำเร็จแล้วเท่านั้น ไม่มีก็ไม่กระทบการล็อกอิน

---

## ข้อมูลตัวอย่างทำงานยังไง

`backend/src/services/sampleData.js` สร้างตัวเลขแบบสุ่มที่ **คงที่ตาม
Steam64 ID** — ใส่ ID เดิมจะได้ตัวเลขเดิมเสมอ (ไม่ใช่สุ่มใหม่ทุกครั้งที่รีเฟรช)
เพื่อให้พฤติกรรมคาดเดาได้ตอนสาธิตหรือเทส

โครงสร้างข้อมูลออกแบบให้ตรงกับ 5 มิติ KPI ที่กำหนดเองใน `backend/src/lib/kpi.js`:
`aim`, `positioning`, `utility`, `clutch`, `opening`

ฟังก์ชันหลัก 3 ตัว:
- `generateProfile(steam64Id)` — โปรไฟล์ผู้เล่น (rating 5 มิติ, สถิติกลไก, แมตช์ล่าสุด)
- `generateMatches(steam64Id)` — ประวัติแมตช์ 20 นัดล่าสุด
- `generateMatchDetails(gameId)` — รายละเอียดแมตช์ 1 นัด (ผู้เล่นทั้ง 10 คน)

**เมื่อ pipeline parse `.dem` เสร็จ** (ดูหัวข้อถัดไป) ให้เขียนไฟล์ใหม่ที่มี
ฟังก์ชัน 3 ตัวนี้ชื่อเดียวกัน คืนค่ารูปแบบเดียวกัน แล้วสลับ import ใน
`routes/players.js`, `routes/matches.js`, `routes/teams.js` — ไม่ต้องแก้ route
หรือ frontend เลยสักบรรทัด เพราะ contract ระหว่างชั้นถูกออกแบบให้สลับได้ตั้งแต่แรก

---

## API ของ backend

ทุกเส้นทางใต้ `/api` ต้องล็อกอินก่อน (อ่าน JWT จาก cookie)

```
GET    /health
GET    /auth/steam                    เริ่ม login
GET    /auth/steam/return             callback จาก Steam
POST   /auth/logout
POST   /auth/dev-login                ข้าม Steam จริง (ปิดเฉพาะตอน production)

GET    /api/me
GET    /api/players/:steam64
GET    /api/players/:steam64/matches
GET    /api/compare?a=…&b=…

GET    /api/matches/:gameId           แมตช์ + โน้ตของแมตช์นั้น
POST   /api/matches/:gameId/notes
DELETE /api/notes/:id

GET    /api/teams
POST   /api/teams                     { name, is_opponent }
DELETE /api/teams/:id
POST   /api/teams/:id/members         { steam64_id, nickname, role }
DELETE /api/teams/:id/members/:memberId
PUT    /api/teams/:id/kpi-weights     { weights: { aim, positioning, … } }
GET    /api/teams/:id/overview        ภาพรวมทีม + คะแนน KPI
```

---

## โครงสร้างฐานข้อมูล

SQLite ไฟล์เดียวที่ `backend/data/app.db` สร้างอัตโนมัติตอนรันครั้งแรก
โครงสร้างอยู่ใน `backend/src/db.js`

```
users         ผู้ใช้ที่ล็อกอินผ่าน Steam
teams         ทีม (ทั้งทีมเราและทีมคู่แข่ง แยกด้วย is_opponent)
team_members  สมาชิกทีม อ้างด้วย steam64_id
coach_notes   โน้ตของโค้ช ผูกกับ match_id
```

**ตั้งใจไม่มีตารางเก็บข้อมูลจาก API ภายนอก** — บทเรียนจากตอนใช้ Leetify คือ
ถ้าจะเชื่อม API ภายนอกตัวไหนในอนาคต ต้องเช็ค ToS เรื่องการเก็บข้อมูลก่อนเสมอ
ก่อนจะออกแบบตาราง cache

สังเกตว่าไม่มีตาราง `matches` / `rounds` / `events` เหมือนใน ER diagram ของ
proposal เดิม เพราะเวอร์ชันนี้ยังไม่ได้ parse ไฟล์ `.dem` เอง (ดูหัวข้อถัดไป)

---

## งานถัดไปที่แนะนำ — pipeline parse `.dem` จริง

นี่คืองานหลักที่เหลือ เพื่อแทนที่ `sampleData.js` ด้วยข้อมูลจริง ตรงกับ
Progress 1 ใน proposal (POC แผนที่ Mirage):

1. **หาไฟล์ `.dem` จริง** อย่างน้อย 1 ไฟล์ (ขอจากทีม UTCC eSports, ดาวน์โหลด
   demo แข่งขันสาธารณะ, หรือ export จากเกมของเพื่อนที่เล่น CS2)
2. **เขียน Python script แยกต่างหาก** ใช้ `awpy` parse ไฟล์ ดึงตำแหน่ง
   kill/death (`attacker_X/Y`, `victim_X/Y`) ออกมา — ไม่ต้องเชื่อมกับเว็บแอปนี้เลย
   ทำเป็น script เดี่ยว ๆ ที่ output เป็นรูป PNG ก่อน (POC)
3. **สร้างตาราง `matches` / `rounds` / `events` จริง** ตาม ER diagram 10 ตาราง
   ที่ออกแบบไว้ (ดู DBML ที่เคยสร้างไว้ในบทสนทนา) — ใช้ PostgreSQL แทน SQLite
   ถ้าข้อมูลเริ่มเยอะ (`events` อาจมีหลักหมื่นแถวเมื่อสะสมหลายแมตช์)
4. **เขียน worker** (Python แยก process หรือ endpoint รับอัปโหลดใน Express)
   ที่ parse แล้วเขียนผลลงตารางเหล่านี้
5. **สลับ `sampleData.js`** เป็นไฟล์ที่อ่านจากตารางจริงแทนการสุ่ม —
   function signature เดิมทุกตัว ไม่ต้องแก้ route/frontend

งานอื่นที่แนะนำเพิ่มเติม:

6. ทำ Heatmap จากพิกัด X-Y-Z ที่ parse ได้ (สิ่งที่ Leetify API ไม่เคยให้เราอยู่แล้ว)
7. ระบุแนวทาง ML ให้ชัด: จะทำนายอะไร (win probability ต่อรอบ?), ใช้ feature
   อะไรเทรน (economy state, จำนวนผู้เล่นที่รอด, การควบพื้นที่), baseline เทียบกับอะไร
8. เขียนเทสต์ให้ `lib/kpi.js` ก่อน เพราะเป็นตรรกะที่กรรมการจะถามแน่

---

## ปัญหาที่เจอบ่อย

**Windows: `npm : File …\npm.ps1 cannot be loaded because running scripts is disabled`**
เป็นการตั้งค่าความปลอดภัยของ PowerShell ไม่เกี่ยวกับโปรเจกต์ แก้ครั้งเดียวจบด้วย
(เปิด PowerShell ธรรมดา ไม่ต้อง Admin):

```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

พิมพ์ `Y` แล้ว Enter จากนั้นใช้ `npm` ได้ตามปกติ

**เห็น `ExperimentalWarning: SQLite is an experimental feature`**
ปกติ ไม่ใช่ error — เป็นแค่คำเตือนจาก Node ว่าโมดูล `node:sqlite` ยังไม่ถูก
ประกาศเสถียร 100% ใช้งานได้ตามปกติ ไม่กระทบฟีเจอร์ใดๆ ในโปรเจกต์นี้

**กด login แล้ว Steam ขึ้น error หรือเด้งกลับไม่ได้**
เช็กว่า `BACKEND_URL` ใน `.env` ตรงกับ URL ที่เปิดจริง Steam จะเด้งกลับตามค่านี้เท่านั้น

**ลืมว่าใครทำส่วนไหน**
ดูตารางส่วนประกอบในสไลด์ System Overview

---

## Changelog

**Sprint 0 (ล่าสุด) — ตัด Leetify ออกทั้งหมด**
1. ลบ `services/leetify.js` และการเรียก API ภายนอกทุกจุด — เหตุผลเต็มอยู่หัวข้อ
   "ทำไมถึงเลิกใช้ Leetify" ด้านบน
2. สร้าง `services/sampleData.js` แทน — generate ข้อมูลตัวอย่างในเครื่องล้วน ๆ
   ไม่มี network call เลย โครงสร้างออกแบบเองไม่ผูกกับ schema ของใคร
3. ตัดตาราง `api_cache` ที่เคยขัด ToS ของ Leetify ออกจาก `db.js`
4. ยืนยันใช้ `node:sqlite` ไม่ใช่ `better-sqlite3` (เคยถูกเปลี่ยนกลับไปมาสองรอบ
   ระหว่างแก้ปัญหาติดตั้งบน Windows — ล็อกไว้ในคอมเมนต์โค้ดแล้ว)
5. ไม่มี `.env` แนบมาในไฟล์ที่แจกจ่าย ต้อง `cp .env.example .env` เองทุกครั้ง
